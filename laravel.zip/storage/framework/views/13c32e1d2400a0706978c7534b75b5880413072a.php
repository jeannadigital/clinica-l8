

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Gestor de Pacientes</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-header">
				
				<a href="Crear-Paciente">
					<button class="btn btn-primary btn-lg">Agregar Paciente</button>
				</a>

			</div>

			<div class="box-body">
				
				<table class="table table-bordered table-hover table-striped">
					
					<thead>
						<tr>
							
							<th>ID</th>
							<th>Nombre y Apellido</th>
							<th>Documento</th>
							<th>Email</th>
							<th>Telefono</th>
							<th>Editar / Borrar</th>

						</tr>
					</thead>

					<tbody>

						<?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
								
								<td><?php echo e($paciente->id); ?></td>
								<td><?php echo e($paciente->name); ?></td>
								<td><?php echo e($paciente->documento); ?></td>
								<td><?php echo e($paciente->email); ?></td>

								<?php if($paciente->telefono != ""): ?>

									<td><?php echo e($paciente->telefono); ?></td>

								<?php else: ?>

									<td>No Disponible</td>

								<?php endif; ?>
								

								<td>
									
									<a href="Editar-Paciente/<?php echo e($paciente->id); ?>">
										
										<button class="btn btn-success"><i class="fa fa-pencil"></i></button>

									</a>

									<button class="btn btn-danger EliminarPaciente" Pid="<?php echo e($paciente->id); ?>" Paciente="<?php echo e($paciente->name); ?>"><i class="fa fa-trash"></i></button>

								</td>

							</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						

					</tbody>

				</table>

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Pacientes.blade.php ENDPATH**/ ?>