

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Inicio</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<div class="col-md-6 bg-primary">
					
					<h1>Bienvenidos</h1>

					<hr>

					<h2>Días:</h2>
					<h3><?php echo e($inicio->dias); ?></h3> 

					<hr>

					<h2>Horarios:</h2>
					<h3>Desde: <?php echo e($inicio->horaInicio); ?></h3>
					<h3>Hasta: <?php echo e($inicio->horaFin); ?></h3>

					<hr>

					<h2>Dirección:</h2>
					<h3><?php echo e($inicio->direccion); ?></h3>

					<hr>

					<h2>Contactos:</h2>

					<h3>Telefono: <?php echo e($inicio->telefono); ?> <br> 
					Correo: <?php echo e($inicio->email); ?></h3>


				</div>
				
				<div class="col-md-6">

                <img src="http://localhost/Clinica-L8/public/storage/<?php echo e($inicio->logo); ?>" class="img-responsive">
				</div>		

			</div>

		</div>

		<?php if(auth()->user()->rol == "Administrador"): ?>
         
         <div class="box-footer">
					
					<a href="<?php echo e(url('Inicio-Editar')); ?>">
						
						<button class="btn btn-success btn-lg">Editar</button>

					</a>

			</div>

			<?php endif; ?>

	   </div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Inicio.blade.php ENDPATH**/ ?>