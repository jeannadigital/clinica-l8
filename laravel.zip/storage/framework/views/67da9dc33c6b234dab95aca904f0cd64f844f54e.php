

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Editar Inicio</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<form method="post" enctype="multipart/form-data">

					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					
					<div class="row">
						
						<div class="col-md-6 col-xs-12">
							
							<h2>Días:</h2>
							<input type="text" class="input-lg" name="dias" value="<?php echo e($inicio->dias); ?>">

							<div class="form-group">
								
								<h2>Horarios:</h2>
								Desde: <input type="time" class="input-lg" name="horaInicio" value="<?php echo e($inicio->horaInicio); ?>">
								Hasta: <input type="time" class="input-lg" name="horaFin" value="<?php echo e($inicio->horaFin); ?>">

							</div>

							<h2>Dirección:</h2>
							<input type="text" class="input-lg" name="direccion" value="<?php echo e($inicio->direccion); ?>">

							<h2>Teléfono:</h2>
							<input type="text" class="input-lg" name="telefono" value="<?php echo e($inicio->telefono); ?>">

							<h2>Correo:</h2>
							<input type="email" class="input-lg" name="email" value="<?php echo e($inicio->email); ?>">

						</div>

						<div class="col-md-6 col-xs-12">
							
							<br><br>

							<h2>Logo:</h2>
							<input type="file" name="logoN">

							<br>

							<img src="http://localhost/Clinica-L8/public/storage/<?php echo e($inicio->logo); ?>" width="200px">

							<br><br>

							<button type="submit" class="btn btn-success">Guardar Cambios</button>

						</div>

					</div>

				</form>

			</div>

		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Inicio-Editar.blade.php ENDPATH**/ ?>