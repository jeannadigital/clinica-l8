

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Elija un Consultorio:</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">

				<?php $__currentLoopData = $consultorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="col-lg-3 col-xs-6">
					
						<a href="Ver-Doctores/<?php echo e($consultorio->id); ?>">
							
							<div class="small-box bg-aqua">
								
								<div class="inner">
									
									<h3><?php echo e($consultorio->consultorio); ?></h3>

								</div>

							</div>

						</a>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Ver-Consultorios.blade.php ENDPATH**/ ?>