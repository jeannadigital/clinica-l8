

<?php $__env->startSection('contenido'); ?>

<div class="login-box">
	
	<div class="login-logo">
		<b>Clínica Médica</b>
	</div>

	<div class="login-box-body">
		
		<p class="login-box-msg">Ingresar al Sistema</p>

		<form method="post" action="<?php echo e(route('login')); ?>">

			<?php echo csrf_field(); ?>
			
			<div class="form-group has-feedback">
				
				<input type="email" id="email" name="email" class="form-control" required="" value="<?php echo e(old('email')); ?>">

				

				<span class="glyphicon glyphicon-user form-control-feedback"></span>

				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<br>
					<div class="alert alert-danger">Error con el Email o la Contraseña</div>

				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			</div>

			<div class="form-group has-feedback">
				
				<input type="password" id="password" name="password" class="form-control" required="" value="">

				<span class="glyphicon glyphicon-lock form-control-feedback"></span>

			</div>

			<div class="row">
				
				<div class="col-xs-12">
					<button type="submit" class="btn btn-primary btn-block btn-flat">Ingresar</button>
				</div>

			</div>

		</form>

	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Ingresar.blade.php ENDPATH**/ ?>