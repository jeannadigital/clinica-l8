

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">

		<?php if($doctor->sexo == "Femenino"): ?>
		
			<h2>Doctora: <?php echo e($doctor->name); ?></h2>	

		<?php else: ?>

			<h2>Doctor: <?php echo e($doctor->name); ?></h2>	

		<?php endif; ?>

		<h2>Horarios</h2>

		<?php if($horarios == null): ?>

			<?php if(auth()->user()->rol == "Doctor"): ?>

				<form method="post" action="<?php echo e(url('Horario')); ?>">

					<?php echo csrf_field(); ?>
					
					<div class="row">
						
						<div class="col-md-2">
							
							Desde <input type="time" class="form-control" name="horaInicio">

						</div>

						<div class="col-md-2">
							
							Hasta <input type="time" class="form-control" name="horaFin">

						</div>

						<br>

						<div class="col-md-1">
							
							<button type="submit" class="btn btn-success">Guardar</button>

						</div>

					</div>

				</form>

			<?php endif; ?>

		<?php else: ?>

			<?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<?php if(auth()->user()->rol == "Doctor"): ?>
					
					<form method="post" action="<?php echo e(url('editar-horario/'.$hora->id)); ?>">

						<?php echo csrf_field(); ?>
						<?php echo method_field('put'); ?>
						
						<div class="row">
							
							<div class="col-md-2">
								
								Desde <input type="time" class="form-control" name="horaInicioE" value="<?php echo e($hora->horaInicio); ?>">

							</div>

							<div class="col-md-2">
								
								Hasta <input type="time" class="form-control" name="horaFinE" value="<?php echo e($hora->horaFin); ?>">

							</div>

							<br>

							<div class="col-md-1">
								
								<button type="submit" class="btn btn-success">Editar</button>

							</div>

						</div>

					</form>

				<?php elseif(auth()->user()->rol == "Paciente"): ?>

					<h2><?php echo e($hora->horaInicio); ?> - <?php echo e($hora->horaFin); ?></h2>

				<?php endif; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			

		<?php endif; ?>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<div id="calendario"></div>

			</div>
			
		</div>

	</section>

</div>


<div class="modal fade" id="CitaModal">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post">

				<?php echo csrf_field(); ?>
				
				<div class="modal-body">
					
					<div class="box-body">
						
						<div class="form-group">
							
							<h2>Seleccionar Paciente</h2>

							<input type="hidden" name="id_doctor" value="<?php echo e(auth()->user()->id); ?>">

							<select required="" name="id_paciente" id="select2" style="width: 100%">
								
								<option value="">Paciente...</option>

								<?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<?php if($paciente->rol == "Paciente"): ?>

										<option value="<?php echo e($paciente->id); ?>"><?php echo e($paciente->name); ?> - <?php echo e($paciente->documento); ?></option>

									<?php endif; ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</select>

						</div>

						<div class="form-group">
							
							<h2>Fecha</h2>
							<input type="text" class="form-control input-lg" id="Fecha" readonly="">

						</div>

						<div class="form-group">
							
							<h2>Hora</h2>
							<input type="text" class="form-control input-lg" id="Hora" readonly="">


							<input type="hidden" name="FyHinicio" class="form-control input-lg" id="FyHinicio" readonly="">
							<input type="hidden" name="FyHfinal" class="form-control input-lg" id="FyHfinal" readonly="">

						</div>

					</div>

				</div>

				<div class="modal-footer">
					
					<button type="submit" class="btn btn-primary">Pedir Cita</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>

				</div>

			</form>

		</div>

	</div>

</div>



<div class="modal fade" id="EventoModal">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post" action="<?php echo e(url('borrar-cita')); ?>">

				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				
				<div class="modal-body">
					
					<div class="form-group">
							
						<h2>Paciente:</h2>
						<h3 id="paciente"></h3>	

						<input type="hidden" name="idCita" id="idCita">

						<?php

							$exp = explode("/", $_SERVER["REQUEST_URI"]);

							echo '<input type="hidden" name="idDoctor" value="'.$exp[4].'">';

						?>

						

					</div>

				</div>

				<div class="modal-footer">
					
					<button type="submit" class="btn btn-warning">Cancelar Cita</button>
					<button type="button" data-dismiss="modal" class="btn btn-danger">Cerrar Cita</button>

				</div>

			</form>

		</div>

	</div>

</div>


<div class="modal fade" id="Cita">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post">

				<?php echo csrf_field(); ?>
				
				<div class="modal-body">
					
					<div class="box-body">
						
						<div class="form-group">

							<?php

								$exp = explode("/", $_SERVER["REQUEST_URI"]);
							
								echo '<input type="hidden" name="id_doctor" value="'.$exp[4].'">';

							?>
							

							<input type="hidden" name="id_paciente" value="<?php echo e(auth()->user()->id); ?>">

						</div>

						<div class="form-group">
							
							<h2>Fecha:</h2>

							<input type="text" class="form-control input-lg" id="FechaP" readonly="">

						</div>

						<div class="form-group">
							
							<h2>Hora:</h2>

							<input type="text" class="form-control input-lg" id="HoraP" readonly="">

						</div>

						<div class="form-group">
							
							<input type="hidden" class="form-control input-lg" id="FyHinicioP" name="FyHinicio" readonly="">

							<input type="hidden" class="form-control input-lg" id="FyHfinalP" name="FyHfinal" readonly="">

						</div>

					</div>

				</div>

				<div class="modal-footer">
					
					<button class="btn btn-primary" type="submit">Pedir Cita</button>

					<button class="btn btn-danger" type="button" data-dismiss="modal">Cancelar</button>

				</div>

			</form>

		</div>

	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Citas.blade.php ENDPATH**/ ?>