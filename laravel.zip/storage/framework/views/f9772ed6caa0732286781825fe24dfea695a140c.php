

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Gestor de Doctores</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-header">
				
				<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#CrearDoctor">Crear Doctor</button>

			</div>

			<div class="box-body">
				
				<table class="table table-bordered table-hover table-striped dt-responsive">
					
					<thead>
						<tr>
							
							<th>ID</th>
							<th>Nombre y Apellido</th>
							<th>Consultorio</th>
							<th>Email</th>
							<th>Documento</th>
							<th>Teléfono</th>

							<th></th>

						</tr>
					</thead>

					<tbody>

						<?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($doctor->rol == "Doctor"): ?>

								<tr>
							
									<td><?php echo e($doctor->id); ?></td>
									<td><?php echo e($doctor->name); ?></td>

									<td><?php echo e($doctor->CON->consultorio); ?></td>

									<td><?php echo e($doctor->email); ?></td>

									<?php if($doctor->documento != ""): ?>

										<td><?php echo e($doctor->documento); ?></td>

									<?php else: ?>

										<td>Aún no Registrado.</td>

									<?php endif; ?>

									<?php if($doctor->telefono != ""): ?>

										<td><?php echo e($doctor->telefono); ?></td>

									<?php else: ?>

										<td>No Disponible.</td>

									<?php endif; ?>


									<td>

										<button class="btn btn-danger EliminarDoctor" Did="<?php echo e($doctor->id); ?>"><i class="fa fa-trash"></i></button>

									</td>

								</tr>


							<?php endif; ?>


						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>

				</table>

			</div>
			
		</div>

	</section>

</div>


<div id="CrearDoctor" class="modal fade">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post">

				<?php echo csrf_field(); ?>
				
				<div class="modal-body">
					
					<div class="box-body">
						
						<div class="form-group">
							
							<h2>Nombre y Apellido:</h2>

							<input type="text" class="form-control input-lg" name="name" required>

						</div>

						<div class="form-group">
							
							<h2>Sexo:</h2>

							<select class="form-control input-lg" name="sexo" required="">
								
								<option value="">Seleccionar...</option>

								<option value="Femenino">Femenino</option>
								<option value="Masculino">Masculino</option>

							</select>

						</div>


						<div class="form-group">
							
							<h2>Consultorio:</h2>

							<select class="form-control input-lg" name="id_consultorio" required="">
								
								<option value="">Seleccionar...</option>

								<?php $__currentLoopData = $consultorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($consultorio->id); ?>"><?php echo e($consultorio->consultorio); ?></option>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</select>

						</div>

						<div class="form-group">
							
							<h2>Email:</h2>

							<input type="email" class="form-control input-lg" name="email" value="<?php echo e(old('email')); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

								<div class="alert alert-danger">El Email ya Existe.</div>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						</div>

						<div class="form-group">
							
							<h2>Contraseña:</h2>

							<input type="text" class="form-control input-lg" name="password" required>

						</div>

					</div>

				</div>

				<div class="modal-footer">
					
					<button type="submit" class="btn btn-primary">Crear</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>

				</div>

			</form>

		</div>

	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Doctores.blade.php ENDPATH**/ ?>