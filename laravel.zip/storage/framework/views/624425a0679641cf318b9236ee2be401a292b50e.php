

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Su Historial de Citas Médicas</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<table class="table table-bordered table-hover table-striped">
					
					<thead>
						<tr>
							
							<th>Fecha y Hora</th>
							<th>Doctor</th>
							<th>Consultorio</th>

						</tr>
					</thead>

					<tbody>
						
						<?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
								
								<td><?php echo e($cita->FyHinicio); ?></td>

								<?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<?php if($cita->id_doctor == $doctor->id): ?>

										<td><?php echo e($doctor->name); ?></td>

										<?php $__currentLoopData = $consultorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

											<?php if($doctor->id_consultorio == $consultorio->id): ?>

												<td><?php echo e($consultorio->consultorio); ?></td>

											<?php endif; ?>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<?php endif; ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



							</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>

				</table>

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Historial.blade.php ENDPATH**/ ?>