

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Gestor de Secretarias</h1>

	</section>	

	<section class="content">
		
		<div class="box">

			<div class="box-header">
				
				<button class="btn btn-primary" data-toggle="modal" data-target="#CrearSecretaria">Crear Secretaria</button>

			</div>
			
			<div class="box-body">
				
				<table class="table table-hover table-bordered table-striped">
					
					<thead>
						<tr>
							
							<th>ID</th>
							<th>Nombre</th>
							<th>Email</th>
							<th>Documento</th>
							<th>Teléfono</th>

							<th>Editar / Borrar</th>

						</tr>
					</thead>

					<tbody>
						
						<?php $__currentLoopData = $secretarias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secretaria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
								
								<td><?php echo e($secretaria->id); ?></td>
								<td><?php echo e($secretaria->name); ?></td>
								<td><?php echo e($secretaria->email); ?></td>

								<?php if($secretaria->documento != ""): ?>

									<td><?php echo e($secretaria->documento); ?></td>

								<?php else: ?>

									<td>No Disponible.</td>

								<?php endif; ?>


								<?php if($secretaria->telefono != ""): ?>

									<td><?php echo e($secretaria->telefono); ?></td>

								<?php else: ?>

									<td>Aún no Registrado.</td>

								<?php endif; ?>

								<td>
									
									<a href="<?php echo e(url('Editar-Secretaria/'.$secretaria->id)); ?>">
										
										<button class="btn btn-success"><i class="fa fa-pencil"></i></button>

									</a>

									<button class="btn btn-danger EliminarSecretaria" Sid="<?php echo e($secretaria->id); ?>"><i class="fa fa-trash"></i></button>

								</td>

							</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>

				</table>

			</div>
			
		</div>

	</section>

</div>


<div class="modal fade" id="CrearSecretaria">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post">

				<?php echo csrf_field(); ?>
				
				<div class="modal-body">
					
					<div class="box-body">
						
						<div class="form-group">
							
							<h2>Nombre y Apellido</h2>

							<input type="text" class="form-control input-lg" name="name" value="<?php echo e(old('name')); ?>">

						</div>

						<div class="form-group">
							
							<h2>Email</h2>

							<input type="email" class="form-control input-lg" name="email" required value="<?php echo e(old('email')); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

								<div class="alert alert-danger">El Email ya Existe...</div>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						</div>

						<div class="form-group">
							
							<h2>Contraseña</h2>

							<input type="text" class="form-control input-lg" name="password" value="<?php echo e(old('password')); ?>">

						</div>

					</div>

				</div>

				<div class="modal-footer">
					
					<button class="btn btn-primary" type="submit">Crear</button>

					<button class="btn btn-danger" type="button" data-dismiss="modal">Cerrar</button>

				</div>

			</form>

		</div>

	</div>

</div>

<div class="modal fade" id="EditarSecretaria">
	
	<div class="modal-dialog">
		
		<div class="modal-content">
			
			<form method="post" action="<?php echo e(url('actualizar-secretaria/'.$secretaria->id)); ?>">

				<?php echo csrf_field(); ?>
				<?php echo method_field('put'); ?>
				
				<div class="modal-body">
					
					<div class="box-body">
						
						<div class="form-group">
							
							<h2>Nombre y Apellido</h2>

							<input type="text" class="form-control input-lg" name="name" value="<?php echo e($secretaria->name); ?>">

						</div>

						<div class="form-group">
							
							<h2>Email</h2>

							<input type="email" class="form-control input-lg" name="email" required value="<?php echo e($secretaria->email); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

								<div class="alert alert-danger">El Email ya Existe...</div>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						</div>

						<div class="form-group">
							
							<h2>Nueva Contraseña</h2>

							<input type="text" class="form-control input-lg" name="passwordN" value="">
							<input type="hidden" name="password" value="<?php echo e($secretaria->password); ?>">

						</div>

					</div>

				</div>

				<div class="modal-footer">
					
					<button class="btn btn-success" type="submit">Guardar Cambios</button>

					<button class="btn btn-danger" type="button" data-dismiss="modal">Cerrar</button>

				</div>

			</form>

		</div>

	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Secretarias.blade.php ENDPATH**/ ?>