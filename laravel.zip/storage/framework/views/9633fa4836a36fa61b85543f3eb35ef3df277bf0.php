
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Doctores del Consultorio de:<br>
        <b><?php echo e($consultorio->consultorio); ?></b></h1>

    </section>
    <section class="content">
        <div class="box">
           <div class="box-body">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                  <tr>
                   <th>Nombre y Apellido</th>
                   <th>Email</th>
                   <th>Teléfono</th>
                   <th>Horario</th>
                   <th></th>
                  </tr>
                </thead>
             <tbody>

                <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <?php if($hora->id_doctor == $doctor->id): ?>

                      <tr>
                        <td><?php echo e($doctor->name); ?></td>
                        <td><?php echo e($doctor->email); ?></td>

                         <?php if($doctor->telefono != ""): ?>
                         <td><?php echo e($doctor->telefono); ?></td>
                         <?php else: ?>
                         <td>No Disponible</td>

                         <?php endif; ?>

                        <td><?php echo e($hora->horaInicio); ?> - <?php echo e($hora->horaFin); ?></td>

                        <td>
                          <a href="<?php echo e(url('Citas/'.$doctor->id)); ?>">
                            <button class="btn btn-primary">Agenda de Citas</button>
                          </a>
                        </td> 
                              
                      <?php endif; ?>

           
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
           </div> 
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Ver-Doctores.blade.php ENDPATH**/ ?>