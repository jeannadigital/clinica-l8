

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Editar el Paciente: <?php echo e($paciente->name); ?></h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-header">
				
				<a href="<?php echo e(url('Pacientes')); ?>">
					
					<button class="btn btn-primary">Volver a Pacientes</button>

				</a>

			</div>

			<div class="box-body">
				
				<form method="post" action="<?php echo e(url('actualizar-paciente/'.$paciente->id)); ?>">

					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					
					<h2>Nombre y Apellido:</h2>
					<input type="text" class="form-control input-lg" name="name" value="<?php echo e($paciente->name); ?>">

					<h2>Documento:</h2>
					<input type="text" class="form-control input-lg" name="documento" value="<?php echo e($paciente->documento); ?>">

					<h2>Email:</h2>
					<input type="text" class="form-control input-lg" name="email" value="<?php echo e($paciente->email); ?>">

					<h2>Nueva Contraseña:</h2>
					<input type="text" class="form-control input-lg" name="passwordN" value="">

					<input type="hidden" class="form-control input-lg" name="password" value="<?php echo e($paciente->password); ?>">

					<br><br>

					<button class="btn btn-success" type="submit">Actualizar</button>

				</form>

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Editar-Paciente.blade.php ENDPATH**/ ?>