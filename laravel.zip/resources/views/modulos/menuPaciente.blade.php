<aside class="main-sidebar">
	
	<section class="sidebar">
		
		<ul class="sidebar-menu">
			
			<li>
				<a href="{{ url('Inicio') }}">
					<i class="fa fa-home"></i>
					<span>Inicio</span>
				</a>
			</li>

			<li>
				<a href="{{ url('Ver-Consultorios') }}">
					<i class="fa fa-calendar-check-o"></i>
					<span>Consultorios</span>
				</a>
			</li>

			<li>
				<a href="{{ url('Historial') }}">
					<i class="fa fa-users"></i>
					<span>Historial</span>
				</a>
			</li>

		</ul>

	</section>

</aside>