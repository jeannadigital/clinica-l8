

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Gestor de Consultorios</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<br>

			<form method="post">

				<?php echo csrf_field(); ?>
				
				<div class="col-md-6 col-xs-12">
					
					<input type="text" class="form-control" name="consultorio" placeholder="Ingrese Nuevo Consultorio" required="">

				</div>

				<button class="btn btn-primary" type="submit">Agregar Consultorio</button>

			</form>

			<br>

			<div class="box-body">

				<?php $__currentLoopData = $consultorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="row">
				
						<form method="post" action="<?php echo e(url('Consultorio/'.$consultorio->id)); ?>">

							<?php echo csrf_field(); ?>
							<?php echo method_field('put'); ?>
							
							<div class="col-md-4">
								
								<input type="text" class="form-control" name="consultorioE" value="<?php echo e($consultorio->consultorio); ?>">

							</div>

							<div class="col-md-1">
								
								<button class="btn btn-success" type="submit">Guardar</button>

							</div>


						</form>

						<div class="col-md-1">
							
							<form method="post" action="<?php echo e(url('borrar-Consultorio/'.$consultorio->id)); ?>">

								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								
								<button type="submit" class="btn btn-danger">Borrar</button>

							</form>

						</div>

					</div>
					<br>


				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				


			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Consultorios.blade.php ENDPATH**/ ?>