

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Mis Datos Personales</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<form method="post">

					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					
					<div class="row">
						
						<div class="col-md-6 col-xs-12">
							
							<h2>Nombre y Apellido</h2>
							<input type="text" class="input-lg" name="name" value="<?php echo e(auth()->user()->name); ?>">

							<h2>Email</h2>
							<input type="email" class="input-lg" name="email" value="<?php echo e(auth()->user()->email); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

								<p class="alert alert-danger">El Email ya Existe.</p>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

							<h2>Nueva Contraseña</h2>
							<input type="text" class="input-lg" name="passwordN" value="">
							
						</div>

						<div class="col-md-6 col-xs-12">
							
							<h2>Documento</h2>
							<input type="text" class="input-lg" name="documento" value="<?php echo e(auth()->user()->documento); ?>">

							<h2>Teléfono</h2>
							<input type="text" class="input-lg" name="telefono" value="<?php echo e(auth()->user()->telefono); ?>">

							<br><br><br>

							<button type="submit" class="btn btn-success">Guardar</button>

						</div>

					</div>

				</form>

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Mis-Datos.blade.php ENDPATH**/ ?>