

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	
	<section class="content-header">
		
		<h1>Crear Paciente</h1>

	</section>	

	<section class="content">
		
		<div class="box">
			
			<div class="box-body">
				
				<form method="post">
				
					<?php echo csrf_field(); ?>

					<div class="form-group">
						
						<h2>Nombre y Apellido:</h2>
						<input type="text" name="name" class="form-control input-lg">

					</div>

					<div class="form-group">
						
						<h2>Documento:</h2>
						<input type="text" name="documento" class="form-control input-lg">

					</div>

					<div class="form-group">
						
						<h2>Email:</h2>
						<input type="email" class="form-control input-lg" name="email" value="<?php echo e(old('email')); ?>">

							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

								<div class="alert alert-danger">El Email ya Existe.</div>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

					</div>

					<div class="form-group">
						
						<h2>Password:</h2>
						<input type="text" name="password" class="form-control input-lg">

					</div>

					<br>

					<button type="submit" class="btn btn-primary btn-lg">Agregar</button>

				</form>

			</div>
			
		</div>

	</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/Crear-Paciente.blade.php ENDPATH**/ ?>