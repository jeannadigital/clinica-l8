<aside class="main-sidebar">
	
	<section class="sidebar">
		
		<ul class="sidebar-menu">
			
			<li>
				<a href="<?php echo e(url('Inicio')); ?>">
					<i class="fa fa-home"></i>
					<span>Inicio</span>
				</a>
			</li>

			<li>
				<a href="<?php echo e(url('Ver-Consultorios')); ?>">
					<i class="fa fa-calendar-check-o"></i>
					<span>Consultorios</span>
				</a>
			</li>

			<li>
				<a href="<?php echo e(url('Historial')); ?>">
					<i class="fa fa-users"></i>
					<span>Historial</span>
				</a>
			</li>

		</ul>

	</section>

</aside><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/menuPaciente.blade.php ENDPATH**/ ?>