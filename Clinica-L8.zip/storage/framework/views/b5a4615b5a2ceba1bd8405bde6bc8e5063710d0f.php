<aside class="main-sidebar">
	
	<section class="sidebar">
		
		<ul class="sidebar-menu">
			
			<li>
				<a href="<?php echo e(url('Inicio')); ?>">
					<i class="fa fa-home"></i>
					<span>Inicio</span>
				</a>
			</li>

			<li>
				<a href="<?php echo e(url('Citas/'.auth()->user()->id)); ?>">
					<i class="fa fa-calendar-check-o"></i>
					<span>Citas</span>
				</a>
			</li>

			<li>
				<a href="<?php echo e(url('Pacientes')); ?>">
					<i class="fa fa-users"></i>
					<span>Pacientes</span>
				</a>
			</li>

		</ul>

	</section>

</aside><?php /**PATH C:\xampp\htdocs\Clinica-L8\resources\views/modulos/menuDoctor.blade.php ENDPATH**/ ?>